// Firebase config placeholder
